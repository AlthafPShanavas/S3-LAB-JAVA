# JavaLabPrograms
Write a java program to <br /><br />
1.print “hello world”<br /> <br />
2.add two numbers <br /><br />
3.check given no is odd or even <br /><br />
4.check given no is prime or not <br /><br />
5.find the sum of first “n” natural numbers <br /><br />
6.find the factor of a given number <br /><br />
7.print Fibonacci series <br /><br />
8.factorial of first n numbers <br /><br />
9.check given no is palindrome or not<br /><br />
10.amstrong or not <br />

