//check given no is palindrome or not
import java.io.*;
import java.util.*;
public class Palindrome{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number to test palindrome");
        int num = scanner.nextInt();
        int temp = num;
        String y = "";
        while(temp !=0)
        {
            int x = temp%10;
            y = y+((x);

        }
    }
    
}
